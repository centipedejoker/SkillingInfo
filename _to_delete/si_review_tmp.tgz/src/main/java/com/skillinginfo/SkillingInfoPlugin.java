package com.skillinginfo;

import com.google.inject.Provides;
import com.skillinginfo.session.ActivitySession;
import com.skillinginfo.session.ItemFlowEntry;
import com.skillinginfo.session.ItemUseStore;
import com.skillinginfo.session.SessionManager;
import com.skillinginfo.session.SessionRepository;
import com.skillinginfo.ui.SkillingInfoPanel;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.inject.Inject;
import javax.swing.SwingUtilities;
import lombok.extern.slf4j.Slf4j;
import net.runelite.api.Client;
import net.runelite.api.GameState;
import net.runelite.api.MenuAction;
import net.runelite.api.TileItem;
import net.runelite.api.coords.WorldPoint;
import net.runelite.api.events.GameStateChanged;
import net.runelite.api.events.GameTick;
import net.runelite.api.events.ItemContainerChanged;
import net.runelite.api.events.ItemDespawned;
import net.runelite.api.events.ItemQuantityChanged;
import net.runelite.api.events.ItemSpawned;
import net.runelite.api.events.MenuOptionClicked;
import net.runelite.api.events.StatChanged;
import net.runelite.api.gameval.InventoryID;
import net.runelite.http.api.loottracker.LootRecordType;
import net.runelite.client.config.ConfigManager;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.game.ItemManager;
import net.runelite.client.game.ItemStack;
import net.runelite.client.game.SkillIconManager;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDependency;
import net.runelite.client.plugins.PluginDescriptor;
import net.runelite.client.plugins.loottracker.LootReceived;
import net.runelite.client.plugins.slayer.SlayerPlugin;
import net.runelite.client.plugins.slayer.SlayerPluginService;
import net.runelite.client.ui.ClientToolbar;
import net.runelite.client.ui.NavigationButton;

@Slf4j
@PluginDescriptor(
	name = "Skilling Info",
	description = "Tracks personal skilling sessions, XP rates, idle time, activity output, actual pickups, dropped items and resources retained.",
	tags = {"skilling", "xp", "tracker", "slayer", "loot", "ironman"}
)
// §5/§37: Slayer task state comes from RuneLite's own Slayer plugin rather
// than being re-derived from chat messages, so it's declared as a
// dependency. Loot arrives via the core Loot Tracker's LootReceived event,
// which needs no declaration.
@PluginDependency(SlayerPlugin.class)
public class SkillingInfoPlugin extends Plugin
{
	@Inject
	private Client client;

	@Inject
	private ClientToolbar clientToolbar;

	@Inject
	private SkillingInfoConfig config;

	@Inject
	private SkillIconManager skillIconManager;

	@Inject
	private ItemManager itemManager;

	@Inject
	private SlayerPluginService slayerPluginService;

	@Inject
	private ConfigManager configManager;

	// Resolved on the client thread (see onGameTick) and read from the EDT
	// by the panel - ItemManager.getItemComposition() asserts it's only
	// ever called on the client thread, so the UI must never call it
	// directly (caught live: SPEC.md v7 changelog).
	private final Map<Integer, String> itemNames = new ConcurrentHashMap<>();

	private ItemUseStore itemUseStore;
	private SessionRepository sessionRepository;
	private SessionManager sessionManager;
	private SkillingInfoPanel panel;
	private NavigationButton navButton;

	@Provides
	SkillingInfoConfig provideConfig(ConfigManager configManager)
	{
		return configManager.getConfig(SkillingInfoConfig.class);
	}

	@Override
	protected void startUp()
	{
		itemUseStore = new ItemUseStore(configManager);
		sessionRepository = new SessionRepository(client);
		sessionManager = new SessionManager(config, sessionRepository, itemUseStore);
		sessionManager.init();

		BufferedImage icon = buildIcon();
		panel = new SkillingInfoPanel(sessionManager, skillIconManager, itemUseStore, itemNames, itemManager, icon);
		panel.refresh();

		navButton = NavigationButton.builder()
			.tooltip("Skilling Info")
			.icon(icon)
			.priority(6)
			.panel(panel)
			.build();

		clientToolbar.addNavigation(navButton);
	}

	@Override
	protected void shutDown()
	{
		// A session in progress is real recorded data. Toggling the plugin
		// off used to discard it silently - onLogout already persists on the
		// way out, and shutdown has exactly the same obligation.
		if (sessionManager != null)
		{
			sessionManager.stop();
		}

		clientToolbar.removeNavigation(navButton);

		// Deliberately not nulling sessionManager/panel: an event already in
		// flight would then NPE on the way through, turning a clean shutdown
		// into a stack trace in the user's log. The instance is discarded
		// either way.
	}

	@Subscribe
	public void onStatChanged(StatChanged event)
	{
		sessionManager.onStatChanged(event.getSkill(), event.getXp());
	}

	@Subscribe
	public void onGameTick(GameTick event)
	{
		sessionManager.onGameTick(client.getTickCount());
		sessionManager.onSlayerTaskUpdate(
			slayerPluginService.getTask(),
			slayerPluginService.getTaskLocation(),
			slayerPluginService.getRemainingAmount());
		resolveItemNames();
		SwingUtilities.invokeLater(this::refreshPanel);
	}

	/**
	 * A rendering fault must not take the plugin down with it: without this,
	 * one exception on the EDT stops the panel updating at all, which is
	 * indistinguishable from tracking having stopped working.
	 */
	private void refreshPanel()
	{
		try
		{
			panel.refresh();
		}
		catch (Exception e)
		{
			log.warn("Skilling Info panel refresh failed", e);
		}
	}

	/**
	 * Runs on the client thread (this handler is invoked there, not the
	 * EDT) so it's safe to call ItemManager here. Resolves and caches the
	 * name of any item that has shown up in the current session's item
	 * flow, or any past session's (history), that hasn't been looked up
	 * yet - the history panel needs names too, not just the live view.
	 * computeIfAbsent makes repeat calls a cheap no-op once cached, so
	 * doing this every tick against a small history list is fine.
	 */
	private void resolveItemNames()
	{
		ActivitySession current = sessionManager.getCurrentSession();
		if (current != null)
		{
			resolveItemNames(current);
		}
		for (ActivitySession session : sessionManager.getHistory())
		{
			resolveItemNames(session);
		}
	}

	private void resolveItemNames(ActivitySession session)
	{
		for (ItemFlowEntry entry : session.getItemFlow())
		{
			itemNames.computeIfAbsent(entry.getItemId(), id -> itemManager.getItemComposition(id).getName());
		}
	}

	@Subscribe
	public void onItemContainerChanged(ItemContainerChanged event)
	{
		if (event.getContainerId() == InventoryID.INV)
		{
			sessionManager.onInventoryChanged(event.getItemContainer().getItems());
		}
		else if (event.getContainerId() == InventoryID.BANK)
		{
			sessionManager.onBankChanged(event.getItemContainer().getItems());
		}
		else if (event.getContainerId() == InventoryID.WORN)
		{
			sessionManager.onEquipmentChanged(event.getItemContainer().getItems());
		}
	}

	@Subscribe
	public void onMenuOptionClicked(MenuOptionClicked event)
	{
		if ("Drop".equals(event.getMenuOption()))
		{
			sessionManager.onDropClicked(event.getItemId());
			return;
		}

		MenuAction action = event.getMenuAction();
		boolean isGroundItemAction = action == MenuAction.GROUND_ITEM_FIRST_OPTION
			|| action == MenuAction.GROUND_ITEM_SECOND_OPTION
			|| action == MenuAction.GROUND_ITEM_THIRD_OPTION
			|| action == MenuAction.GROUND_ITEM_FOURTH_OPTION
			|| action == MenuAction.GROUND_ITEM_FIFTH_OPTION;
		if (isGroundItemAction && "Take".equals(event.getMenuOption()))
		{
			sessionManager.onTakeClicked(event.getId());
		}
	}

	/**
	 * §37/§18: NPC drops, taken from RuneLite's own loot tracking rather
	 * than re-derived from raw events (§5). Only NPC and EVENT loot counts -
	 * a pickpocket or a clue casket is not this session's monster loot.
	 */
	@Subscribe
	public void onLootReceived(LootReceived event)
	{
		if (event.getType() != LootRecordType.NPC && event.getType() != LootRecordType.EVENT)
		{
			return;
		}

		Map<Integer, Integer> items = new HashMap<>();
		for (ItemStack stack : event.getItems())
		{
			items.merge(stack.getId(), stack.getQuantity(), Integer::sum);
		}
		sessionManager.onNpcLootReceived(items);
	}

	@Subscribe
	public void onItemSpawned(ItemSpawned event)
	{
		WorldPoint point = event.getTile().getWorldLocation();
		sessionManager.onGroundItemSpawned(point, event.getItem());
	}

	@Subscribe
	public void onItemQuantityChanged(ItemQuantityChanged event)
	{
		WorldPoint point = event.getTile().getWorldLocation();
		sessionManager.onGroundItemQuantityChanged(point, event.getItem());
	}

	@Subscribe
	public void onItemDespawned(ItemDespawned event)
	{
		WorldPoint point = event.getTile().getWorldLocation();
		sessionManager.onGroundItemDespawned(point, event.getItem());
	}

	@Subscribe
	public void onGameStateChanged(GameStateChanged event)
	{
		if (event.getGameState() == GameState.LOGGED_IN)
		{
			// account hash isn't resolvable until now - reload so history
			// comes from the right account's file, not the "unknown" bucket
			// used before login (SessionRepository)
			sessionManager.init();
			SwingUtilities.invokeLater(this::refreshPanel);
		}
		else if (event.getGameState() == GameState.LOGIN_SCREEN)
		{
			sessionManager.onLogout();
			SwingUtilities.invokeLater(this::refreshPanel);
		}
	}

	private BufferedImage buildIcon()
	{
		BufferedImage image = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = image.createGraphics();
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g.setColor(new Color(83, 155, 231));
		g.fillOval(1, 1, 14, 14);
		g.setColor(Color.WHITE);
		g.setFont(g.getFont().deriveFont(Font.BOLD, 9f));
		g.drawString("SI", 3, 11);
		g.dispose();
		return image;
	}
}
